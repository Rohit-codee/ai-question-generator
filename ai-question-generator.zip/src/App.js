import React, { useState } from 'react';

function App() {
  const [text, setText] = useState("");
  const [output, setOutput] = useState("");

  const handleSubmit = () => {
    // Simulate generating questions (you can later replace with real logic or API call)
    const sampleOutput = `Generated Questions for: "${text}"\n1. What is this about?\n2. Write true/false based on the above.`;
    setOutput(sampleOutput);
  };

  return (
    <div style={{ padding: "20px", fontFamily: "Arial" }}>
      <h1>AI Question Generator</h1>
      <textarea
        rows="6"
        style={{ width: "100%" }}
        placeholder="Enter your text or paste content here..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <button onClick={handleSubmit} style={{ marginTop: "10px" }}>
        Generate Questions
      </button>
      {output && (
        <pre style={{ marginTop: "20px", backgroundColor: "#f0f0f0", padding: "10px" }}>
          {output}
        </pre>
      )}
    </div>
  );
}

export default App;